package rac;

/**
 * Abstract Factory to manufacture RACs.
 */
public interface IRACFactory {
    /**
     * Returns an empty IRAContainer.
     */
    public abstract IRAContainer makeRAC();
}

