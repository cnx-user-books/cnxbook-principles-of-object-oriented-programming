
/**
 * Title:        Ball World<p>
 * Description:  <p>
 * Copyright:    Copyright (c) DXN, SBW<p>
 * Company:      Rice University<p>
 * @author DXN
 * @version 1.0
 */
package ballworld;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import command.*;


/**
 * A subclass of JFrame containing the various GUI components specified in the program behavior specification.
 * Provides a Container area where the drawing object is to be drawn.
 */
public class BallGUI extends JFrame {
  
  
  private JPanel _controlPnl = new JPanel();
  
  private ILambda _paintCmd = NoOpLambda.Singleton;
  
  private JPanel _canvasPnl = new JPanel() {
    public void paint(Graphics g) {
      super.paint(g);
      _paintCmd.apply(g);
    }
  };
  private JButton _makeBallBtn = new JButton("Make Ball");
  private JButton _clearAllBtn = new JButton("ClearAll");
  private JTextField _inputTF = new JTextField("ballworld.StraightBall");
  
  
  /**
   * Initializes and lays out the GUI components.
   */
  public BallGUI(final ILambda makeBallCmd, final ILambda clearBallsCmd, ILambda paintCmd) {
    _paintCmd = paintCmd;   
    try {
      init();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    setSize (new Dimension(600, 450));
    _makeBallBtn.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        makeBallCmd.apply(_inputTF.getText());
      }
    });
    
    _clearAllBtn.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        clearBallsCmd.apply(null);
      }
    });
  }
  
  private void init() throws Exception {
    this.setTitle("Ball World");
    this.getContentPane().setLayout(new BorderLayout());
    this.getContentPane().add(_controlPnl, BorderLayout.NORTH);
    //_canvasPnl.setBackground(Color.BLACK);
    this.getContentPane().add(_canvasPnl, BorderLayout.CENTER);
    _controlPnl.add(_inputTF);
    _controlPnl.add(_makeBallBtn);
    _controlPnl.add(_clearAllBtn);
    
  }
  
  
  //Overridden so we can exit on System Close
  protected void processWindowEvent(WindowEvent e)
  {
    super.processWindowEvent(e);
    if(e.getID() == WindowEvent.WINDOW_CLOSING)
    {
      System.exit(0);
    }
  }
    
  /**
   * Accessor method for the panel upon which the balls are to be drawn
   */
  public Container getContainer()
  {
    return _canvasPnl;
  }
}