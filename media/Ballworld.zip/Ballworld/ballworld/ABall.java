package ballworld;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * An abstract ball that moves in a line with its given velocity and bounces off
 * the walls of a rectangularly shaped container.
 * Has a Point representing its center, an int representing its radius, a Point representing its velocity, a Color representing its color.
 */
public abstract class ABall implements Observer {
  /**
   * The present location of the center of the ball.
   */
  private Point location;
  /**
   * The radius of the ball.
   */
  private int radius;
  /**
   * The current velocity of the ball.   Given in terms of an X and Y increment per update interval.
   */
  private Point velocity;
  /**
   * The color of the ball.
   */
  private Color color;

  /**
   * The Container that is currently holding this ball and defines where the walls are
   */
  private Container _container;
  
  
  /**
   * Intializes this Ball to a given center, radius,  color, containing walls, and the NullStrategy to move in a straight line.
   * @param r the initial radius of this Ball.
   * @param v the initial velocity of this Ball.
   * @param c The initial color of the ball.
   * @param p the initial center of this Ball.
   * @param container the rectangular Container area where this Ball is drawn.
   */
  public ABall(Point p, int r, Point v, Color c, Container container)
  {
    location = p;
    radius = r;
    velocity = v;
    color = c;
    _container = container;
  }
  
  /**
   * Moves to the new position, updates the attributes of this Ball and paints it.
   */
  public void update(Observable o, Object g)
  {
    updateState();
    // Moves the ball by the X and Y increments specified by the velocity property.
    location.translate (velocity.x, velocity.y);
    bounce();
    paint((Graphics) g);
  }
  
  /**
   * Checks if the ball needs to bounce off the wall of its container
   */
  public void bounce()
  {
    int _minX = radius;
    int _minY = radius;
    int _maxX = _container.getWidth() -radius;
    int _maxY = _container.getHeight() - radius;
    if (location.x < _minX)
    {
      location.x = _minX; 
      velocity.x = -velocity.x;
    }
    else if(location.x > _maxX)
    {
      location.x = _maxX;
      velocity.x = -velocity.x;
    }
    if (location.y < _minY)
    {
      location.y = _minY;
      velocity.y = -velocity.y;
    }
    else if(location.y > _maxY)
    {
      location.y = _maxY;
      velocity.y = -velocity.y;
    }
  }
  
  /**
   * Sets the center to a new location.
   * @param location the new center.
   */
  public void setLocation(Point location)
  {
    this.location = location;
  }
  
  /**
   * Returns the current center of this Ball.
   * @return a Point representing the center of this Ball.
   * @SBGen Method get location
   */
  public Point getLocation()
  {
    // SBgen: Get variable
    return(location);
  }
  
  /**
   * Sets the radius of this Ball to a new radius.
   * @param radius the new radius for this Ball.
   * @SBGen Method set radius
   */
  public void setRadius(int radius)
  {
    // SBgen: Assign variable
    this.radius = radius;
  }
  
  /**
   * Returns the current radius for this Ball.
   * @return the radius of this Ball.
    */
  public int getRadius()
  {
    return(radius);
  }
  
  /**
   * Sets the velocity of this Ball to a new velocity.
   * @param velocity the new velocity for this Ball.
   */
  public void setVelocity(Point velocity)
  {
    this.velocity = velocity;
  }
  
  /**
   * Returns the current velocity of this Ball.
   * @return the current velocity of this Ball.
   */
  public Point getVelocity()
  {
    return(velocity);
  }
  
  /**
   * Sets the color of this Ball to a given color.
   * @param color the new color for this Ball.
   */
  public void setColor(Color color)
  {
    this.color = color;
  }
  
  /**
   * Returns the current color of this Ball.
   * @return the color of this Ball.
   */
  public Color getColor()
  {
    return(color);
  }
  
  /**
   * Paints the image of the ball onto a Graphics object.
   * @param g a Graphics object.
   */
  public void paint(Graphics g)
  {
    g.setColor (color);
    g.fillOval (location.x-radius, location.y-radius, 2*radius, 2*radius);
  }
  
  
  public abstract void updateState();
}
