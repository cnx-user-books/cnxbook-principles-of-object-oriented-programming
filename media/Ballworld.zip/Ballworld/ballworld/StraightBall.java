package ballworld;
import java.awt.*;

public class StraightBall extends ABall {
  public StraightBall(Point p, int r, Point v, Color c, Container container) {
    super(p, r, v, c, container);
  }

  public void updateState() {
  }
}
