package ballworld;
import java.awt.*;


public class CurveBall extends ABall {
  private double angle = Randomizer.randomDouble(.01, Math.PI/4.0);
  private double cosA = Math.cos(angle);
  private double sinA = Math.sin(angle);
  
  public CurveBall(Point p, int r, Point v, Color c, Container container) {
    super(p, r, v, c, container);
  }

  
  
  public void updateState() {
    Point v = getVelocity();
    v.setLocation(cosA*v.getX()+ sinA*v.getY(), cosA*v.getY()-sinA*v.getX());
  }
}
