package command;
/**
 * Represents the identity map.  Null-object pattern for ILambda.
 * @author Dung X. Nguyen
 */
public class NoOpLambda implements ILambda
{
  /**
   * This is the class field that gives access to the one instance of this class
   */
  public static final NoOpLambda Singleton = new NoOpLambda ();
  
  /**
   * A private constructor keeps everyone except this class from constructing an instance.
   */
  private NoOpLambda()
  {
  }
  
  /**
   * Does nothing.
   * @return arg as is.
   */
  public Object apply (Object arg)
  {
    return arg;
  }
}