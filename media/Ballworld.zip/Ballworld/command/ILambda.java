package command;

/**
* Represents the abstract lambda expression whose sole purpose in life is to
* evaluate itself on an input and return the result of the evaluation.
* @author Dung X. Nguyen
*/
public abstract interface ILambda
{
	/**
	 * Performs some computation with a given input Object.
	 * Returns an Object as the result.
	 * @param arg input object for this ILambda object.
	 * @return an output object resulting from evaluating the lambda expression on the input arg.
	 */
	public abstract Object apply(Object arg);
}

