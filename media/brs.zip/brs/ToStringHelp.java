
package brs;

/**
 * Computes a String representation of the binary tree host so that it can be
 * printed vertically, given a leftmost leading string for the two subtrees.
 * Called by ToString.
 * Should be implemented as an anonymous inner class in the call by ToString.
 * @author Dung X. Nguyen - Copyright 2005 - All rights reserved.
 */
public class ToStringHelp implements IVisitor {
    public final static ToStringHelp Singleton = new ToStringHelp ();
    private ToStringHelp () {
    }

    /**
    * Returns "|_[]" to denote an empty tree subtree.
    * @param host an empty binary (sub)tree.
    * @param nu not used.
    * @return String
    */
    public Object emptyCase(BiTree host, Object... nu) {
        return "|_ []";
    }

    /**
    * Computes a String representation of the binary tree host so that it
    * can be printed vertically.
    * There is no '\n' at the end of the String.
    * @param host a non-empty binary (sub)tree.
    * @param leftLead[0] appropriate leftmost leading String to help compute the
    * String representations of the left and right subtrees.
    * @return String
    */
    public Object nonEmptyCase(BiTree host, Object... leftLead) {
        String ls
            = (String)host.getLeftSubTree().execute(this, leftLead[0] + "|  ");
        String rs
            = (String)host.getRightSubTree().execute(this, leftLead[0] + "   ");
        return ("|_ " + host.getRootDat()+ "\n" +
                leftLead[0] + ls + "\n" +
                leftLead[0] + rs);
    }
}

