package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Same functionality as Frame2 but uses an adapter interface to communicate
 * with the outside world instead.  This design allows varying the communication
 * with the outside world.  How the outside world reacts to the events that
 * happen to the view is a variant behavior!
 * Uses the Null-Object Pattern to initialize the adapter avoiding checking for
 * null.
 * @author DXN
 */
public class Frame3 extends Frame2 {

    // Initializes the adapter to a null object:
    private IView2World _v2wAdapter = new IView2World() {
        public Object button1Clicked (ActionEvent e) {
            return null; // does nothing!
        }
        public Object button2Clicked (ActionEvent e) {
            return null; // does nothing!
        }
    };

    public Frame3(String title) {
        super(title);
    }

    public void setV2WAdapter(IView2World v2w) {
        if (null == v2w) {
            throw new IllegalArgumentException("Argument cannot be null!");
        }
        _v2wAdapter = v2w;
    }

    /**
     * Tells _v2wAdapter the button click event happens on jb1.
     */
    protected void jb1Clicked(ActionEvent e) {
        _v2wAdapter.button1Clicked(e);
    }

    /**
     * Tells _v2wAdapter the button click event happens on jb2.
     */
    protected void jb2Clicked(ActionEvent e) {
        _v2wAdapter.button2Clicked(e);
    }

}