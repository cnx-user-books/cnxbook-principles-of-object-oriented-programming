package view;

import java.awt.event.*;

/**
 * Adapter connecting Frame3 (the View) to the outside world.
 */
public interface IView2World {
    /**
     * Called by Frame3 when its button 1 is clicked.
     */
    public Object button1Clicked (ActionEvent e);

    /**
     * Called by Frame3 when its button 2 is clicked.
     */
    public Object button2Clicked (ActionEvent e);
}