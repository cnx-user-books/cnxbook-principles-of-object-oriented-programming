package app;

import view.*;
import controller.*;

/**
 * Instantiates the controller and builds the frame!
 */
public class Frame3App {

    public static void main(String[] args) {
        new Frame3Controller().constructFrame().validate();
    }
}