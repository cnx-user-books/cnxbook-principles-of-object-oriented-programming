package app;

import javax.swing.*;
import view.*;

public class Frame2App {

    public static void main(String[] args) {
        JFrame f = new Frame2("A JFrame with 2 JButtons with event listeners");
        f.setVisible(true);
        f.setSize(300, 100);  // Guess what this does!
        f.setLocation(200, 200);  // Guess what this does!

        // Forces the frame to re-layout its components:
        f.validate();
    }
}