package controller;

import view.*;
import java.awt.event.*;
import javax.swing.JFrame;
import java.awt.*; // For layout managers.

/**
 * The controller that instantiates a concrete IView2World object and connects
 * the world outside of Frame3 (the view) to Frame3.
 * The concrete adapter is implemented as an anonymous inner classe.
 */
public class Frame3Controller {

    public JFrame constructFrame()  {
        // Local variable needs to be final so that the local inner class
        // can access it:
        final Frame3 frame = new Frame3("View and Controller");

        /**
         * Install as concrete anonymous IView2World adapter in frame, without
         * frame knowing what the adapter does.
         */
        frame.setV2WAdapter(new IView2World()  {

            public Object button1Clicked (ActionEvent e) {
                frame.getContentPane().setLayout(new GridLayout(2,1));
                frame.validate();
                return null;
            }

            public Object button2Clicked (ActionEvent e) {
                frame.getContentPane().setLayout(new FlowLayout());
                frame.validate();
                return null;
            }
        });
        frame.setVisible(true);
        return frame;
    }
}

