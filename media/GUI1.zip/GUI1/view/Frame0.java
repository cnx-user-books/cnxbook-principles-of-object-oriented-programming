package view;

import javax.swing.*;  // to use JFrame.

/**
 * Minimal code to create a JFrame with a title and a window event
 * listener to call on System.exit() and force termination of the main
 * application that creates this JFrame.
 * @author D.X. Nguyen
 */
public class Frame0 extends AFrame {

    public Frame0(String title) {
        // Always call the superclass's constuctor:
        super(title);
    }

    protected void initialize() {
        // Do nothing!
    }
}