package app;

import javax.swing.*;
import view.*;

/**
 * A GUI application that simply brings a Frame0 object "into life".
 */
public class Frame0App {

    public static void main(String[] args) {
        JFrame f = new Frame0("A blank JFrame");
        f.setVisible(true);
    }
}