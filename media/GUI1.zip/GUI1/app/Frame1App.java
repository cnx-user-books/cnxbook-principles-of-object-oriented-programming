package app;

import javax.swing.*;
import view.*;

public class Frame1App {

    public static void main(String[] args) {
        JFrame f = new Frame1("A JFrame with 2 JButtons");
        f.setVisible(true);
        // f.setSize(300, 100);  // Guess what this does!
        // f.setLocation(200, 200);  // Guess what this does!
    }
}