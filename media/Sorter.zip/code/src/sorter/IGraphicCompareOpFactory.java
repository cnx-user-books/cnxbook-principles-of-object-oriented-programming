
package sorter;

import java.awt.Color;

public interface IGraphicCompareOpFactory
{
 public AOrder getCompareOp(final Color compareColor, final int waitTime);
}

