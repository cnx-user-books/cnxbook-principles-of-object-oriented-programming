package sorter;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;

public class Applet1 extends JApplet
{
    boolean isStandalone = false;
    JButton runBtn = new JButton();

    //Get a parameter value
  public String getParameter(String key, String def)
    {
        return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
    }

    //Construct the applet
  public Applet1()
    {
    }

    //Initialize the applet
  public void init()
    {
        try 
        {
            jbInit();
        }
        catch(Exception e) 
        {
            e.printStackTrace();
        }
    }

    //Component initialization
  private void jbInit() throws Exception
    {
        runBtn.setText("Click to run Program");
        runBtn.addActionListener(new java.awt.event.ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                runBtn_actionPerformed(e);
            }
        });
        this.setSize(new Dimension(400,300));
        this.getContentPane().add(runBtn, BorderLayout.CENTER);
    }

    //Get Applet information
  public String getAppletInfo()
    {
        return "Applet Information";
    }

    //Get parameter info
  public String[][] getParameterInfo()
    {
        return null;
    }
    // static initializer for setting look & feel
    static {
        try
        {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            //UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        }
        catch (Exception e) {}
    }

    void runBtn_actionPerformed(ActionEvent e)
    {
        (new Frame1(WindowConstants.DISPOSE_ON_CLOSE)).setVisible(true);
    }

}    
