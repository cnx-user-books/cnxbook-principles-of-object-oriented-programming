
package sorter;

public interface ICompareOp
{

 /**
  * @param x 
  * @param y 
  */
 public boolean eq(Object x, Object y);

 public boolean ne(Object x, Object y);

 public boolean lt(Object x, Object y);

 public boolean le(Object x, Object y);

 public boolean gt(Object x, Object y);

 public boolean ge(Object x, Object y);
}

