package sorter;

public class SorterApp
{

  //Main method
  public static void main(String[] args) {
    (new SorterFrame()).setVisible(true);
  }
} 