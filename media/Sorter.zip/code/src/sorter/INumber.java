
package sorter;

public interface INumber
{
 /**
  * Accessor method for the stored value.
  * @return
  */
 public int getValue();
}

