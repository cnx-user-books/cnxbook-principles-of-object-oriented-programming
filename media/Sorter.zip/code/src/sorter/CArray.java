
package sorter;

import java.util.Vector;

public class CArray extends ACollection
{
  private Vector v = new Vector();
  
  /**
   * @param size
   */
  public CArray(int size)
  {
    v= new Vector(size);
  }
  
  /**
   * @param idx
   * @return
   */
  public Object getAt(int idx)
  {
    return (v.elementAt(idx));
  }
  
  /**
   * @param idx
   * @param data
   */
  public void setAt(Object data, int idx)
  {
    v.setElementAt(data, idx);
  }
}

