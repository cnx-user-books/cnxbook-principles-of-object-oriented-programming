package sorter;

 public abstract class ACommand
{
  public abstract void execute(Object x);
} 