
package sorter;

public abstract class ACompareOp
{
}

