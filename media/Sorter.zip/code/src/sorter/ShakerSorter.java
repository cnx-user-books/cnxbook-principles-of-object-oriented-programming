
package sorter;

public class ShakerSorter extends ASorter
{
  

  /**
   * @param iCompareOp
   */
  public ShakerSorter(AOrder iCompareOp)
  {
    super(iCompareOp);
  }
  
  /**
   * Splits A[lo:hi] into A[lo:s-1] and A[s:hi] where s is the returned value of this function.
   * @param A the array A[lo:hi] to be sorted.
   * @param lo the low index of A.
   * @param hi the high index of A.
   * @return
   */
  protected int split(Object[] A, int lo, int hi)
  {
    return hi;  // STUB CODE!  REPLACE WITH STUDENT CODE.
  }
  
  /**
   * Joins sorted A[lo:s-1] and sorted A[s:hi] into A[lo:hi].
   * @param A A[lo:s-1] and A[s:hi] are sorted.
   * @param lo the low index of A.
   * @param s
   * @param hi the high index of A.
   */
  protected void join(Object[] A, int lo, int s, int hi)
  {
  }
}

