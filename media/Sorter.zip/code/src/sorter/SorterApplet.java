package sorter;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;

public class SorterApplet extends JApplet
{
  private JButton startBtn = new JButton();
  private JLabel jLabel1 = new JLabel();
    
  //Initialize the applet
  public void init()
  {
    startBtn.setFont(new java.awt.Font("Dialog", 1, 30));
    startBtn.setText("Click Here To Run Demo");
    startBtn.addActionListener(new java.awt.event.ActionListener(){    
      public void actionPerformed(ActionEvent e)
      {
        (new SorterFrame(WindowConstants.DISPOSE_ON_CLOSE)).setVisible(true);
      }
    });
    this.setSize(new Dimension(200,100));
    jLabel1.setText("Java 2 must be installed on your machine in order to run this applet!");
    this.getContentPane().add(startBtn, BorderLayout.CENTER);
    this.getContentPane().add(jLabel1, BorderLayout.NORTH);
  }
  
}