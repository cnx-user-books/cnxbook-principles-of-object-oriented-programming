
package sorter;

public abstract class ACollection
{
 /**
  * @param idx
  */
 public abstract Object getAt(int idx);

 /**
  * @param idx
  * @param data
  */
 public abstract void setAt(Object data, int idx);
}

