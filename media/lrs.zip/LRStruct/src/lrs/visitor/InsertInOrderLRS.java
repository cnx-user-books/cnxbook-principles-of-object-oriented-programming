package lrs.visitor;
import lrs.*;

public class InsertInOrderLRS implements IAlgo {

  public static final InsertInOrderLRS Singleton 
                                  = new InsertInOrderLRS();

  private InsertInOrderLRS() {
  }

  /**
  * Simply inserts the given parameter n at the front.
  * @param host an empty LRStruct.
  * @param n n[0] isan Integer to be inserted in order into host.
  * @return LRStruct
  */
  public Object emptyCase(LRStruct host, Object... n) {
    return host.insertFront(n[0]);
  }

  /**
  * Based on the comparison between first and n,
  * inserts at the front or recurs!
  * @param host a non-empty LRStruct.
  * @param n n[0] is  an Integer to be inserted in order into host.
  * @return LRStruct
  */
  public Object nonEmptyCase(LRStruct host, Object... n) {
    if ((Integer)n[0] < (Integer)host.getFirst()) {
      return host.insertFront(n[0]);
    }
    else {
      return host.getRest().execute(this, n[0]);
    }
  }
}