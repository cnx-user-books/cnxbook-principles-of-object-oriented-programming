package listFW;

/**
 * Represents the structural behavior of the immutable empty list.
 * The empty list has no well-defined structural behavior:
 * it has no first and no rest.
 * @author Dung X. Nguyen
 * @author Stephen B. Wong
 * @since Copyright 2002 - DXN, SBW All rights reserved
 */
public interface IMTList extends IList {
}

