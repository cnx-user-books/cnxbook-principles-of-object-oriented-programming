package listFW.visitor;
import listFW.*;

/**
 * Computes a String reprsentation of IList showing a left parenthesis followed
 * by elements of the IList separated by commas, ending with with a right parenthesis.
 * Non-tail recursive version.
 * Uses private static named helper class.
 * @stereotype visitor
 * @author D.X. Nguyen
 * @since 03/08/2004
 */
public class ToString3WithHiddenHelper implements IListAlgo {
    
    public static final ToString3WithHiddenHelper Singleton = new ToString3WithHiddenHelper();
    private ToString3WithHiddenHelper() {
    }
    
    /**
     * Helps ToString3WithAnonymousHelper compute the String representation of the rest of the list.
     */
    private static class HiddenHelper implements IListAlgo {
        public static final HiddenHelper Singleton = new HiddenHelper();
        private HiddenHelper() {
        }
        
        /**
         * Returns ")".
         * At end of list: done!  
         */
        public Object emptyCase(IMTList host, Object... nu) {
            return ")";
        }
        
        /**
         */
        public Object nonEmptyCase(INEList host, Object... nu) {
            return ", " + host.getFirst() + host.getRest().execute(this);
        }
    }


    /**
     * Returns "()".
     */
    public Object emptyCase(IMTList host, Object... nu) {
        return "()";
    }
    
    /**
     * Passes "(" + first to the rest of IList and 
     * asks for help to complete the computation.
     */
    public Object nonEmptyCase(INEList host, Object... nu) {
        return "(" + host.getFirst() + host.getRest().execute(HiddenHelper.Singleton);
    }
}

