package listFW.visitor;
import listFW.*;

/**
 * Computes a String reprsentation of IList showing  a left parenthesis followed
 * by elements of the IList separated by commas, ending with with a right parenthesis.
 * @stereotype visitor
 * @author D.X. Nguyen
 * @since 02/27/2004
 */
public class ToString1 implements IListAlgo {
    
    public static final ToString1 Singleton = new ToString1();
    private ToString1() {
    }
    
    /**
     * Returns "()".
     */
    public Object emptyCase(IMTList host, Object... nu) {
        return "()";
    }
    
    /**
     * Passes "(" + first to the rest of IList and asks for help to complete the computation.
     */
    public Object nonEmptyCase(INEList host, Object... nu) {
        return host.getRest().execute(ToString1Help.Singleton, "(" + host.getFirst());
    }
}

/**
 * Helps ToString1 compute the String representation of the rest of the list.
 */
class ToString1Help implements IListAlgo {
    public static final ToString1Help Singleton = new ToString1Help();
    private ToString1Help() {
    }
    
    /**
     * Returns the accumulated String + ")".
     * At end of list: done!  
     */
    public Object emptyCase(IMTList host, Object... acc) {
        return  acc[0] + ")";
    }
    
    /**
     * Continues accumulating the String representation by appending ", " + first to acc
     * and recur!
     */
    public Object nonEmptyCase(INEList host, Object... acc) {
        return host.getRest().execute(this, acc[0] + ", " + host.getFirst());
    }
}

