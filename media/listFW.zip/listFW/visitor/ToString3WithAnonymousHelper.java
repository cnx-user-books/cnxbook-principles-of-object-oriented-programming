package listFW.visitor;
import listFW.*;

/**
 * Computes a String reprsentation of IList showing a left parenthesis followed
 * by elements of the IList separated by commas, ending with with a right parenthesis.
 * Non-tail recursive version.
 * Uses private anonymous helper class.
 * @stereotype visitor
 * @author D.X. Nguyen
 * @since 03/08/2004
 */
public class ToString3WithAnonymousHelper implements IListAlgo {    
    public static final ToString3WithAnonymousHelper Singleton = new ToString3WithAnonymousHelper();
    private ToString3WithAnonymousHelper() {
    }
    
    /**
     * Anonymous IListAlgo to help ToString3WithAnonymousHelper compute 
     * the String representation of the rest of the list.
     */
    private static final IListAlgo AnonymousHelper = new IListAlgo() {

        /**
         * Returns ")".
         * At end of list: done!  
         */
        public Object emptyCase(IMTList host, Object... nu) {
            return ")";
        }
        
        /**
         */
        public Object nonEmptyCase(INEList host, Object... nu) {
            return ", " + host.getFirst() + host.getRest().execute(this);
        }
    };  // PAY ATTENTION TO THE SEMI-COLON HERE!

    /**
     * Returns "()".
     */
    public Object emptyCase(IMTList host, Object... nu) {
        return "()";
    }
    
    /**
     * Passes "(" + first to the rest of IList and 
     * asks for help to complete the computation.
     */
    public Object nonEmptyCase(INEList host, Object... nu) {
        return "(" + host.getFirst() + host.getRest().execute(AnonymousHelper);
    }
}

