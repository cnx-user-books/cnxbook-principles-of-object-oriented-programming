package listFW.visitor;
import listFW.*;

/**
 * Computes a String reprsentation of IList showing  a left parenthesis followed
 * by elements of the IList separated by commas, ending with with a right parenthesis.
 * Uses private static named helper class.
 * @stereotype visitor
 * @author D.X. Nguyen
 * @since 03/08/2004
 */
public class ToString2WithHiddenHelper implements IListAlgo {    
    public static final ToString2WithHiddenHelper Singleton = new ToString2WithHiddenHelper();
    private ToString2WithHiddenHelper() {
    }
    
    /**
     * Helps ToString2WithHiddenHelper compute the String representation of the rest of the list.
     */
    private static class HiddenHelper implements IListAlgo {
        public static final HiddenHelper Singleton = new HiddenHelper();
        private HiddenHelper() {
        }
        
        /**
         * Returns "(" + the accumulated String + ")".
         * At end of list: done!  
         */
        public Object emptyCase(IMTList host, Object... acc) {
            return  "(" + acc[0] + ")";
        }
        
        /**
         * Continues accumulating the String representation by appending
         * ", " + first to acc and recur!
         */
        public Object nonEmptyCase(INEList host, Object... acc) {
            return host.getRest().execute(this, acc[0] + ", " + host.getFirst());
        }
    }
    
    /**
     * Returns "()".
     */
    public Object emptyCase(IMTList host, Object... nu) {
        return "()";
    }
    
    /**
     * Passes "(" + first to the rest of IList and asks for help to complete the computation.
     */
    public Object nonEmptyCase(INEList host, Object... nu) {
        return host.getRest().execute(HiddenHelper.Singleton, host.getFirst().toString());
    }
}


