package listFW.visitor;
import listFW.*;

/**
 * Computes a String reprsentation of IList showing  a left parenthesis followed
 * by elements of the IList separated by commas, ending with with a right parenthesis.
 * Uses private anonymous helper class.
 * @stereotype visitor
 * @author D.X. Nguyen
 * @since 03/08/2004
 */
public class ToString1WithAnonymousHelper implements IListAlgo {    
    public static final ToString1WithAnonymousHelper Singleton = new ToString1WithAnonymousHelper();
    private ToString1WithAnonymousHelper() {
    }
    
    /**
     * Anonymous inner class to help ToString1WithAnonymousHelper compute
     * the String representation of the rest of the list.
     */
    private static final IListAlgo AnonymousHelper = new IListAlgo() {        
        /**
         * Returns the accumulated String + ")".
         * At end of list: done!  
         */
        public Object emptyCase(IMTList host, Object... acc) {
            return  acc[0] + ")";
        }
        
        /**
         * Continues accumulating the String representation by appending 
         * ", " + first to acc and recur!
         */
        public Object nonEmptyCase(INEList host, Object... acc) {
            return host.getRest().execute(this, acc[0] + ", " + host.getFirst());
        }
    };  // PAY ATTENTION TO THE SEMI-COLON HERE!
    
    /**
     * Returns "()".
     */
    public Object emptyCase(IMTList host, Object... nu) {
        return "()";
    }
    
    /**
     * Passes "(" + first to the rest of IList and asks for help to complete the computation.
     */
    public Object nonEmptyCase(INEList host, Object... nu) {
        return host.getRest().execute(AnonymousHelper, "(" + host.getFirst());
    }
}


