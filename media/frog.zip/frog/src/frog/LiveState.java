package frog;
import java.awt.*;

/**
 * @stereotype concrete state
 */
class LiveState extends AFrogState {
  /**
   * Singleton instance of this class.
   */
  static final LiveState Singleton = new LiveState();
  
  /**
   * Private constructor this class, hidden by use of singleton pattern.
   */
  private LiveState() {}
  
  /**
   * Accessor method for the color of the frog.
   * @param context The context of this state.
   * @return Color.GREEN always.
   */
  Color getColor(Frog context) {
    return Color.GREEN;
  }
  
  /**
   * Move request to move the frog by translating the given amount.
   * @param context The context of this state.
   * @return The new position of the frog.
   */
  Point moveBy(Frog context, Point delta) {
    context.getPos().translate(delta.x, delta.y);
    return context.getPos();
  }
  
  /**
   * Hits the frog.  The frog will enter the dead state.
   * @param context The context of this state.
   * @return The frog.
   */
  IFrog getHit(Frog context) {
    context.setState(DeadState.Singleton);
    return context;
  }
}

