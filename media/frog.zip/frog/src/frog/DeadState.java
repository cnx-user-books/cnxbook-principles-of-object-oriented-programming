package frog;
import java.awt.*;

/**
 * @stereotype concrete state
 */
class DeadState extends AFrogState {
  /**
   * Singleton instance of this class.
   */
  final static DeadState Singleton = new DeadState();
  
  /**
   * Private constructor this class, hidden by use of singleton pattern.
   */
  private DeadState() {}
  
  /**
   * Accessor method for the color of the frog.
   * @param context The context of this state.
   * @return Color.RED always.
   */
  Color getColor(Frog host) {
    return Color.RED;
  }
  
  /**
   * Move request to move the frog--No effect.
   * @param context The context of this state.
   * @return The current position of the frog.
   */
  Point moveBy(Frog host, Point delta) {
    return host.getPos();
  }
  
  /**
   * Hits the frog.   No effect.
   * @param context The context of this state.
   * @return The frog.
   */
  IFrog getHit(Frog host) {
    return host;
  }
}

