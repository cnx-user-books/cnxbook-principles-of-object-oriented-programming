package frog;
import java.awt.*;

/**
 * An implementation of IFrog using external states encapsulated by the frog package.
 * @stereotype context
 */
public class Frog implements IFrog
{
  /**
   * The current position of the frog.
   */
  private Point _pos = new Point(0,0);
  
  /**
   * The current state of the frog.
   */
  private AFrogState _state = LiveState.Singleton;
  
  /**
   * Accessor method for the position of the frog.
   * @return The current position Point of the frog
   */
  public Point getPos() {
    return _pos;
  }
  
  /**
   * Accessor method for the color of the frog.
   * A live frog is green and a dead frog is red.
   * @return The Color of the frog
   */
  public Color getColor() {
    return _state.getColor(this);
  }
  
  /**
   * Requests that the frog be translated the position by the given vector (Point).   
   * Live frogs move by the given amount.   Dead frogs do not move.
   * @param delta The amount to move the frog by.
   * @return The resultant position of the frog
   */
  public Point moveBy(Point delta) {
    return _state.moveBy(this, delta);
  }
  
  /**
   * The hits the frog.   
   * A live frog will die when it gets hit.   
   * A dead frog stays dead when gets hit. 
   * @return The frog itself is returned.
   */
  public IFrog getHit() {
    return _state.getHit(this);
  }
  
  /**
   * Sets the state of the frog.
   * @param s The new state of the frog.
   */
  void setState(AFrogState s) {
    _state = s;
  }
}

