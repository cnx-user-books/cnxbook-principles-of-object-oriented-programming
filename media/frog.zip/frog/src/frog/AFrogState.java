package frog;

import java.awt.*;

/**
 * Represents an abstract state of a frog.
 * @stereotype abstract state
 */
abstract class AFrogState {
  
  /**
   * Accessor method for the color of the frog.
   * @param context The context of this state.
   * @return The color of the frog.
   */
  abstract Color getColor(Frog context);
  
  /**
   * Move request to move the frog.
   * @param context The context of this state.
   * @return The new position of the frog.
   */
  abstract Point moveBy(Frog context, Point delta);
  
  /**
   * Hits the frog.
   * @param context The context of this state.
   * @return The frog.
   */
  abstract IFrog getHit(Frog context);
}

