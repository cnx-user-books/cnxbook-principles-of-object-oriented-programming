import junit.framework.TestCase;  // Tells the compiler where to find the TestCase class.

/**
 * A JUnit test case class for the Pet class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class Test_Pet extends TestCase {
  
  /**
   * test the hoursSlept method
   * Note the use of the tolerance parameter in the assertEquals.   
   * This is because doubles won't compare exactly due to 
   * round-off errors (same as the build-up of errors when calculating
   * using significant digits in chemistry class).
   */
  public void test_hoursSlept() {
    Person owner = new Person(1, 21, 2005);
    Pet p1 = new Pet(10, owner);
    assertEquals("No food", 0.0, p1.hoursSlept(0), 1e-9);
    assertEquals("25% body weight", 6.0, p1.hoursSlept(2.5), 1e-9);
    assertEquals("50% body weight", 12.0, p1.hoursSlept(5.0), 1e-9);
    assertEquals("100% body weight", 24.0, p1.hoursSlept(10.0), 1e-9);
    assertEquals("150% body weight", 36.0, p1.hoursSlept(15.0), 1e-9);    

    Pet p2 = new Pet(3.14, owner);
    assertEquals("No food", 0.0, p2.hoursSlept(0), 1e-9);
    assertEquals("25% body weight", 6.0, p2.hoursSlept(0.785), 1e-9);
    assertEquals("50% body weight", 12.0, p2.hoursSlept(1.57), 1e-9);
    assertEquals("100% body weight", 24.0, p2.hoursSlept(3.14), 1e-9);
    assertEquals("150% body weight", 36.0, p2.hoursSlept(4.71), 1e-9);    
  }

  /**
   * test the isHappyToSee method
   */
  public void test_isHappyToSee() {
    Person owner = new Person(1, 21, 2005);
    Person nonOwner = new Person(3, 15, 2001);
    Pet p1 = new Pet(10, owner);
    assertEquals("Sees owner", true, p1.isHappyToSee(owner));
    assertEquals("Sees non-owner", false, p1.isHappyToSee(nonOwner));
    Person mrX = owner;   // use different reference to owner
    assertEquals("Sees owner as MrX", true, p1.isHappyToSee(mrX));
    
  }
  
}
