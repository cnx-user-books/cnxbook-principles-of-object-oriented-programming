/**
 * A class that models a household pet
 */
public class Pet{
  
  /**
   * The weight of the pet in lbs
   */
  private double weight;  
  
  /**
   * The pet's owner
   */
  private Person owner;
  
  /**
   * The constructor for to create an instance of a Pet
   * @param weight The weight of the pet in lbs
   * @param owner The Person instance who is the owner of this Pet
   */
  public Pet(double weight, Person owner) {
    this.weight = weight;
    this.owner = owner;
  }
  
  /**
   * The number of hours the pet will sleep after eating
   * the given lbs of food.
   * @param lbsOfFood The number of lbs of food eaten.
   * @return The number of hours slept after eating the food.
   */
  public double hoursSlept(double lbsOfFood) {
    return 24.0*lbsOfFood/weight;
  }
  
  /**
   * Determines whether or not this pet is happy to see a 
   * particular person. 
   * @param p The person who the pet sees.
   * @return true if the Person is their owner, false otherwise.
   */
  public boolean isHappyToSee(Person p) {
    return p == owner;
  }
}
