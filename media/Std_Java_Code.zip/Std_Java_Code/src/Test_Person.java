import junit.framework.TestCase;   // Tells the compiler where to find the TestCase class.


/**
 * A JUnit test case class for the Person class.
 */
public class Test_Person extends TestCase {
  
  /**
   * A tests the nMonthTillBMonth method.
   */
  public void test_nMonthTillBMonth() {
    Person p1 = new Person(1, 21, 2005);
    assertEquals("Zero months until Jan.", 0, p1.nMonthTillBMonth(1));
    assertEquals("1 months until Jan.", 1, p1.nMonthTillBMonth(12));
    assertEquals("7 months until Jan.", 7, p1.nMonthTillBMonth(6));
    
    Person p2 = new Person(5, 3, 2005);
    assertEquals("Zero months until May", 0, p2.nMonthTillBMonth(5));
    assertEquals("1 months until May", 1, p2.nMonthTillBMonth(4));
    assertEquals("7 months until May", 7, p2.nMonthTillBMonth(10));
    
  }
  
}
