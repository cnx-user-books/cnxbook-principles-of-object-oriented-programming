/**
 * A class that models a person with a birthday
 */
public class Person {

  /**
   * birth month; for example, 3 means March.
   */
  private int _bMonth; 
 
  /**
   * Birth day 
   */
  private int _bDay;   
  
  /**
   * birth year 
   */
  private int _bYear; 
  
  /**
   * Constructor to create an instance of a Person
   * @param bMonth The person's birth month (1-12)
   * @param bDay The persons birthdate in the month.
   * @param bYear The person's birth year.
   */
  public Person(int bMonth, int bDay, int bYear) {
    _bMonth = bMonth;
    _bDay = bDay;
    _bYear = bYear;
  }
  
  
  /**
   * Uses "modulo" arithmetic to compute the number of months till the next 
   * birth month given the current month.   
   * @param currentMonth An int representing the current month.
   * @return The number of months from the given month to the birth month.
   */
  public int nMonthTillBMonth(int currentMonth) {
    return (_bMonth - currentMonth + 12) % 12;
  }
}
